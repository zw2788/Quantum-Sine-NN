"""Read settings.py, run the searches, and optionally generate all result plots."""
import subprocess
import sys
from datetime import datetime
from pathlib import Path
import settings
import plot_settings


def build_commands(config, folder, output):
    # Translate readable settings into the existing tested command-line interface.
    # Argument lists (not shell strings) safely handle paths containing spaces.
    command = [sys.executable, str(folder/'run_grid.py'),
               '--mode', config.NETWORK_MODE,
               '--min-width', str(config.MIN_NEURONS_PER_LAYER),
               '--widths', *map(str, config.WIDTHS),
               '--depths', *map(str, config.DEPTHS),
               '--methods', *config.METHODS,
               '--seeds', str(config.NUMBER_OF_SEEDS),
               '--seed-start', str(config.START_SEED),
               '--budget', str(config.MAX_EVALUATIONS_PER_SEED),
               '--split-seed', str(config.DATA_SPLIT_SEED),
               '--t-start', str(config.SA_START_TEMPERATURE),
               '--t-end', str(config.SA_END_TEMPERATURE),
               '--population', str(config.GA_POPULATION_SIZE),
               '--crossover', str(config.GA_CROSSOVER_PROBABILITY),
               '--reference-tol', str(config.REFERENCE_LOSS_TOLERANCE),
               '--output', str(output)]
    if config.GA_MUTATION_PROBABILITY is not None:
        command += ['--mutation', str(config.GA_MUTATION_PROBABILITY)]
    if config.RESUME:
        command.append('--resume')
    plots = [sys.executable, str(folder/'plot_results.py'), str(output)]
    if getattr(config, 'PLOT_ONLY_MISS', True):
        plots.append('--heatmap-only')
    if config.CURVE_WIDTH is not None:
        plots += ['--width', str(config.CURVE_WIDTH)]
    if config.CURVE_DEPTH is not None:
        plots += ['--depth', str(config.CURVE_DEPTH)]
    return command, plots


def main():
    # Locate all scripts relative to this file, independent of the current terminal
    # directory. The underlying runner validates search settings before execution.
    plot_settings.validate()
    folder = Path(__file__).resolve().parent
    if settings.RESUME and settings.RESULTS_FOLDER is None:
        raise ValueError('To resume, set RESULTS_FOLDER to an existing run folder.')
    if settings.RESULTS_FOLDER is None:
        output = folder/'results'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    else:
        output = Path(settings.RESULTS_FOLDER)
        if not output.is_absolute():
            output = folder/output
    # Validate plotting choices before spending time running the searches.
    if settings.MAKE_PLOTS:
        if settings.CURVE_WIDTH is not None and settings.CURVE_WIDTH not in settings.WIDTHS:
            raise ValueError('CURVE_WIDTH must be one of WIDTHS.')
        if settings.CURVE_DEPTH is not None and settings.CURVE_DEPTH not in settings.DEPTHS:
            raise ValueError('CURVE_DEPTH must be one of DEPTHS.')
    command, plots = build_commands(settings, folder, output)
    print(f'Architectures: {len(settings.WIDTHS)*len(settings.DEPTHS)}; methods: {settings.METHODS}', flush=True)
    print(f'Seeds per method/architecture: {settings.NUMBER_OF_SEEDS}; maximum evaluations per seed: {settings.MAX_EVALUATIONS_PER_SEED}', flush=True)
    # Stop immediately if searching fails; do not try to plot incomplete summaries.
    subprocess.run(command, check=True)
    if settings.MAKE_PLOTS:
        subprocess.run(plots, check=True)
    print(f'Finished. Results: {output}', flush=True)


if __name__ == '__main__':
    main()
