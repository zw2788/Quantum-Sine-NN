"""Configurable decreasing-width DSinNN and the original 200-point regression dataset.

All optimizer-visible weights are strictly -1/+1. No STE or gradients are used.
The current desktop source uses activation threshold 0.1, not older 0.01 variants.
"""
import math
import numpy as np
import torch
import torch.nn.functional as F


def make_data(split_seed=42):
    # Reproduce the desktop script's float32 grid, sum order, rounding and split.
    # A dedicated Torch generator makes this split independent of search seeds.
    x = torch.linspace(-7*math.pi, 7*math.pi, steps=200, dtype=torch.float32).reshape(-1, 1)
    y = torch.round(torch.sin(x)+torch.sin(2*x)+torch.sin(3*x)+torch.sin(4*x)+torch.sin(5*x))
    order = torch.randperm(200, generator=torch.Generator().manual_seed(split_seed))
    train, test = order[:160], order[160:]
    return dict(x=x, y=y, train_indices=train, test_indices=test,
                train_x=x[train], train_y=y[train], test_x=x[test], test_y=y[test])


class DSinNN:
    def __init__(self, width, depth, mode='decreasing', min_width=5):
        # Depth counts ALL sine layers, including the first input-to-hidden layer.
        # There is no learned final readout: final discrete activations are summed.
        if width < 1 or depth < 1 or min_width < 1 or mode not in ['constant','decreasing']:
            raise ValueError('Invalid architecture.')
        if mode == 'decreasing' and width < min_width:
            raise ValueError('First-layer width must be at least min_width.')
        self.width, self.depth = width, depth
        self.mode, self.min_width = mode, min_width
        # Width is the FIRST hidden layer size. Match the original desktop model:
        # remove one neuron per layer, then stay at the minimum width (default 5).
        self.layer_widths = [width if mode == 'constant' else max(min_width,width-i)
                             for i in range(depth)]
        self.shapes = list(zip(self.layer_widths, [1]+self.layer_widths[:-1]))
        self.output_width = self.layer_widths[-1]
        self.n_weights = sum(out_size*in_size for out_size,in_size in self.shapes)

    @staticmethod
    def activation(z):
        # Match BinarizeSinParams in the current desktop Discrete source.
        return torch.where(z > 0.1, 1.0, torch.where(z < -0.1, -1.0, 0.0))

    @torch.inference_mode()
    def predict(self, weights, x):
        # Unpack a flat binary chromosome in the same row-major order as nn.Linear.
        weights = torch.as_tensor(weights, dtype=torch.float32)
        offset, out = 0, x
        for layer, shape in enumerate(self.shapes):
            count = shape[0]*shape[1]
            matrix = weights[offset:offset+count].reshape(shape)
            offset += count
            # First layer w0=1; later layers use the original fan-in scaling.
            # Scale the matrix before F.linear, preserving the reference order.
            # The scale depends on THIS layer's input width, which changes in
            # decreasing mode. Reusing the first width would change the model.
            fan_in = shape[1]
            scale = min(math.pi/2, math.pi/(2**(math.floor(math.log2(fan_in))-1)))
            out = F.linear(out, matrix if layer == 0 else scale*matrix)
            out = self.activation(torch.sin(out+0.1))
        return out.sum(dim=1, keepdim=True)

    def loss(self, weights, x, y):
        return float(torch.mean((self.predict(weights, x)-y)**2).item())


class Objective:
    def __init__(self, model, data, budget):
        self.model, self.data, self.budget = model, data, budget
        self.history, self.best_history = [], []
        self.best_loss, self.best_weights = float('inf'), None
        self.unique = set()

    def __call__(self, weights):
        # One call evaluates a COMPLETE 160-point training set. Repeated candidates
        # are charged again; no global memoization changes the algorithm's budget.
        if self.done:
            raise RuntimeError('Evaluation requested after termination.')
        value = self.model.loss(weights, self.data['train_x'], self.data['train_y'])
        self.history.append(value)
        self.unique.add(np.packbits(np.asarray(weights) > 0).tobytes())
        if value < self.best_loss:
            self.best_loss, self.best_weights = value, np.array(weights, dtype=np.int8, copy=True)
        self.best_history.append(self.best_loss)
        return value

    @property
    def done(self):
        # No estimated optimum is supplied to the optimizer. Stop at budget or
        # the rigorous MSE lower bound zero; most larger runs use the full budget.
        return len(self.history) >= self.budget or self.best_loss == 0.0
