#!/bin/bash
# Submit ONE plotting job using existing search results. No new searches.
set -eo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./cluster_env.sh
set -u
exec python -B submit_replot.py "$@"
