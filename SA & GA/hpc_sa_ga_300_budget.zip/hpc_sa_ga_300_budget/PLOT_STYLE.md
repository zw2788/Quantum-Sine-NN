本版图的风格及精确判据见README_HPC.md。
右侧为Train/Test: Not Reaching Best-known Loss (%)及绝对tolerance，取消Bad Local Min名称。
所有阈值使用同一参考值；主图统计绝对差，相对差仅保存在CSV作补充。
