@echo off
setlocal
cd /d "%~dp0"
set "MPLBACKEND=Agg"
"%USERPROFILE%\Anaconda3\python.exe" -B replot_only.py %*
pause
