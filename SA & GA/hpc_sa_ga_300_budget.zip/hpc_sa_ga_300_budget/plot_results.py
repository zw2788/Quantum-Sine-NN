"""Compare absolute loss-gap tolerances using saved SA/GA runs."""
import argparse
import csv
import json
from datetime import datetime
import plot_settings
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

# Match the manuscript's Computer Modern serif appearance without requiring TeX
# or system font installation on the HPC. Matplotlib bundles these font files.
_FONT_DIR = Path(matplotlib.get_data_path())/'fonts'/'ttf'
_ROMAN_FONT = font_manager.FontProperties(fname=str(_FONT_DIR/'cmr10.ttf'))
_BOLD_FONT = font_manager.FontProperties(fname=str(_FONT_DIR/'cmb10.ttf'))
plt.rcParams.update({
    'text.usetex': False, 'font.family': 'serif', 'font.serif': ['cmr10'],
    'mathtext.fontset': 'cm', 'axes.formatter.use_mathtext': True,
    'axes.unicode_minus': False, 'svg.fonttype': 'path',
    'axes.linewidth': 1.0, 'xtick.direction': 'out', 'ytick.direction': 'out',
})


def save(fig, folder, name):
    # Both raster and editable vector exports are provided for manuscript use.
    fig.savefig(folder/f'{name}.png', dpi=200, bbox_inches='tight')
    fig.savefig(folder/f'{name}.svg', bbox_inches='tight')
    plt.close(fig)


def heatmap(rows, settings, field, title, name, folder, split, threshold):
    # Keep the same empirical statistics; only presentation changes here.
    # Actual coordinate edges align width/depth labels with cell centres.
    widths, depths = sorted(settings['widths']), sorted(settings['depths'])
    methods = settings['methods']
    def edges(values):
        a = np.asarray(values,dtype=float)
        if len(a)==1:return np.array([a[0]-.5,a[0]+.5])
        return np.r_[a[0]-(a[1]-a[0])/2,(a[:-1]+a[1:])/2,a[-1]+(a[-1]-a[-2])/2]
    fig, axes = plt.subplots(1,len(methods),figsize=(6.4*len(methods),4.8),
                             squeeze=False,layout='constrained')
    for ax, method in zip(axes[0],methods):
        matrix = np.full((len(depths),len(widths)),np.nan)
        for row in rows:
            if row['method']==method:
                matrix[depths.index(int(row['depth'])),widths.index(int(row['width']))] = 100*float(row[field])
        cmap = plt.get_cmap('Reds').copy()
        cmap.set_bad('#bdbdbd')
        image = ax.pcolormesh(edges(widths),edges(depths),np.ma.masked_invalid(matrix),
                             cmap=cmap,vmin=0,vmax=100,shading='flat',edgecolors='none')
        # Major width labels every five for manuscript-size grids. On a small
        # pilot grid spanning fewer than five neurons, label each actual width.
        ticks = (np.arange(5*np.ceil(min(widths)/5),max(widths)+1,5)
                 if max(widths)-min(widths)>=5 else widths)
        ax.set_xticks(ticks)
        ax.set_xticks([w for w in widths if w not in ticks],minor=True)
        ax.set_yticks(depths)
        ax.set_xlim(edges(widths)[0],edges(widths)[-1])
        ax.set_ylim(edges(depths)[0],edges(depths)[-1])
        ax.tick_params(which='major',labelsize=13,length=3,width=.8)
        ax.tick_params(which='minor',length=2,width=.6)
        for label in ax.get_xticklabels()+ax.get_yticklabels():
            label.set_fontproperties(_ROMAN_FONT)
            label.set_fontsize(13)
        ax.set_xlabel('Neuron Number (1st Hidden Layer)'
                      if settings.get('mode','constant')=='decreasing'
                      else 'Neuron Number (Each Hidden Layer)',
                      fontproperties=_BOLD_FONT,fontsize=17)
        ax.set_ylabel('Number of Hidden Layers',fontproperties=_BOLD_FONT,fontsize=17)
        # Method is identified in filenames, not in a heading above the plot.
        # Deliberately no numerical annotations inside cells. Exact percentages
        # remain available in the adjacent CSV output.
    bar = fig.colorbar(image,ax=list(axes[0]),shrink=.85,fraction=.05,pad=.035,
                       ticks=np.arange(0,101,20))
    bar.set_label(f'{split.title()}: Not Reaching\nBest-known Loss (%)\n(tolerance = {threshold:g})',
                  fontproperties=_BOLD_FONT,fontsize=13)
    for label in bar.ax.get_yticklabels():
        label.set_fontproperties(_ROMAN_FONT)
        label.set_fontsize(12)
    # Keep full budget/architecture/metric metadata in a sidecar, not a large
    # multi-line heading competing with the manuscript-style figure.
    (folder/(name+'_caption.txt')).write_text(
        title+'\nMethods: '+', '.join(methods)+
        '\nArchitecture mode: '+settings.get('mode','constant')+
        '\nMinimum width: '+str(settings.get('min_width','n/a'))+
        '\nColor range: 0--100%; gray cells indicate missing data.\n'
        'Cell numbers omitted; exact values are recorded in the CSV.\n',encoding='utf-8')
    save(fig,folder,name)


def threshold_token(value):
    # Stable, exact float identifiers prevent distinct thresholds sharing files.
    return str(float(value)).removesuffix('.0').replace('.','p').replace('-','m').replace('+','')


def load_records(results, settings):
    # Read complete per-seed losses; a mean loss cannot determine a miss rate.
    records=[]
    for width in settings['widths']:
        for depth in settings['depths']:
            for method in settings['methods']:
                path=results/f'w{width}_d{depth}_{method}'/'runs.csv'
                if not path.is_file():raise ValueError(f'Missing seed-level file: {path}')
                with path.open(encoding='utf-8-sig',newline='') as stream:
                    group=list(csv.DictReader(stream))
                expected=list(range(settings['seed_start'],settings['seed_start']+settings['seeds']))
                if sorted(int(r['seed']) for r in group)!=expected:
                    raise ValueError(f'Missing or duplicate seeds: {path}')
                for r in group:
                    if (int(r['width']),int(r['depth']),r['method'])!=(width,depth,method):
                        raise ValueError(f'Wrong architecture/method: {path}')
                    for key in ['best_train_mse','test_mse']:
                        value=float(r[key])
                        if not np.isfinite(value) or value<0:raise ValueError(f'Invalid loss: {path}')
                    records.append(dict(width=width,depth=depth,method=method,seed=int(r['seed']),
                                        train_loss=float(r['best_train_mse']),test_loss=float(r['test_mse'])))
    return records


def analyse(records, settings, thresholds):
    # References are computed ONCE and reused across thresholds and methods.
    # Test losses belong to training-selected weights; no test-guided search.
    summaries=[]
    for width in settings['widths']:
        for depth in settings['depths']:
            pool=[r for r in records if r['width']==width and r['depth']==depth]
            references={s:min(r[s+'_loss'] for r in pool) for s in ['train','test']}
            for r in pool:
                for split,reference in references.items():
                    gap=r[split+'_loss']-reference
                    r[split+'_reference_mse']=reference
                    r[split+'_absolute_gap']=gap
                    r[split+'_relative_gap']=(gap/reference if reference>plot_settings.RELATIVE_REFERENCE_FLOOR else '')
            for method in settings['methods']:
                group=[r for r in pool if r['method']==method]
                for split,reference in references.items():
                    gaps=np.array([r[split+'_absolute_gap'] for r in group])
                    for threshold in thresholds:
                        # Strictly greater means outside tolerance; equality is
                        # a hit. No twofold rule or additional 0.0001 gate is used.
                        count=int(np.count_nonzero(gaps>threshold))
                        summaries.append(dict(width=width,depth=depth,method=method,split=split,
                            threshold_mode='absolute',threshold=threshold,reference_mse=reference,
                            completed_seeds=len(group),budget=settings['budget'],not_reaching_count=count,
                            not_reaching_rate=count/len(group),not_reaching_percent=100*count/len(group),
                            mean_loss=float(np.mean([r[split+'_loss'] for r in group])),
                            mean_absolute_gap=float(gaps.mean()),median_absolute_gap=float(np.median(gaps)),
                            max_absolute_gap=float(gaps.max()),
                            mean_relative_gap=(float(gaps.mean())/reference
                                if reference>plot_settings.RELATIVE_REFERENCE_FLOOR else '')))
    return summaries


def write_csv(path, rows):
    with path.open('w',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results',type=Path,help='Completed merged/results directory with config.json and w*/runs.csv.')
    # Retain compatibility with the existing experiment and Slurm launchers.
    parser.add_argument('--heatmap-only',action='store_true')
    parser.add_argument('--width',type=int,default=None)
    parser.add_argument('--depth',type=int,default=None)
    parser.add_argument('--output-directory',type=Path,default=None)
    args=parser.parse_args()
    plot_settings.validate()
    results=args.results.resolve()
    settings=json.loads((results/'config.json').read_text(encoding='utf-8'))['settings']
    records=load_records(results,settings)
    thresholds=[float(v) for v in plot_settings.ABSOLUTE_GAP_THRESHOLDS]
    stats=analyse(records,settings,thresholds)
    # A new timestamped folder preserves existing plots and source data.
    folder=(args.output_directory.resolve() if args.output_directory else
            results/'threshold_figures'/datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    folder.mkdir(parents=True,exist_ok=False)
    write_csv(folder/'threshold_statistics.csv',stats)
    write_csv(folder/'per_run_gaps.csv',records)
    for threshold in thresholds:
        dest=folder/('absolute_gap_'+threshold_token(threshold));dest.mkdir()
        selected=[r for r in stats if r['threshold']==threshold]
        write_csv(dest/'train_test_statistics.csv',selected)
        for method in settings['methods']:
            display=dict(settings,methods=[method])
            for split in ['train','test']:
                rows=[r for r in selected if r['split']==split]
                heatmap(rows,display,'not_reaching_rate',
                        f'{method.upper()} {split}: loss - pooled best-known {split} loss > {threshold:g}',
                        f'{method}_{split}_not_reaching_best_known_loss',dest,split,threshold)
    metadata=dict(source_results=str(results),experiment_settings=settings,
        threshold_mode='absolute',thresholds=thresholds,comparison='loss - reference > threshold',
        reference='Per architecture and split, minimum over all included methods and seeds.',
        relative_reference_floor=plot_settings.RELATIVE_REFERENCE_FLOOR,
        relative_gap='(loss-reference)/reference; blank when reference <= relative_reference_floor',
        figures=len(settings['methods'])*2*len(thresholds))
    (folder/'analysis_config.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    (folder/'figure_notes.txt').write_text(
        'Colorbar: fraction NOT reaching the best-known loss WITHIN the stated absolute MSE tolerance.\n'
        'Miss iff L - Lref > threshold; equality is within tolerance. No extra relative or 0.0001 criterion.\n'
        'References are pooled across included methods/seeds separately for each architecture and split.\n'
        'All thresholds use the SAME fixed references. Stricter tolerances cannot decrease the miss rate.\n'
        'Train and test evaluate the SAME training-selected weights. Test data never guide the search.\n'
        'Best-known is empirical, NOT a certified global minimum; failure does not prove a local minimum.\n'
        'Relative gap columns are blank near zero reference, not silently regularised or plotted as zero.\n'
        'Zero percent means all runs meet this tolerance; it does NOT mean zero MSE.\n',encoding='utf-8')
    (folder/'PLOTS_COMPLETE.txt').write_text('All requested threshold figures generated.\n',encoding='utf-8')
    print(f'Threshold figures ({metadata["figures"]} PNG/SVG pairs): {folder}',flush=True)


if __name__=='__main__':
    main()
