#!/bin/bash
# Match the user's existing Burgundy scripts. This file is sourced on BOTH the
# login node and compute nodes; edit these two defaults if the cluster changes.
if [[ "${DSINNN_USE_CURRENT_ENV:-0}" != "1" ]]; then
    if ! type module >/dev/null 2>&1; then
        echo 'The module command is unavailable. Start a normal HPC login shell, or activate an environment and set DSINNN_USE_CURRENT_ENV=1.' >&2
        return 1
    fi
    # Burgundy's legacy miniconda module requires old_modules, which conflicts
    # with default. Repeating this sequence in compute jobs is intentional.
    if [[ "${DSINNN_MODULE:-miniconda/python-3.9}" == "miniconda/python-3.9" ]]; then
        module unload default
        module load old_modules
    fi
    module load "${DSINNN_MODULE:-miniconda/python-3.9}"
    # source activate is the activation form used in your original .sh files.
    source activate "${DSINNN_CONDA_ENV:-sinenv}"
fi
