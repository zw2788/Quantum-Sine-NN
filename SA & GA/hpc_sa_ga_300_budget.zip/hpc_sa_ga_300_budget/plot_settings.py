"""Plotting-only settings: changing these does not require new searches."""
import math

# A run is outside the tolerance iff loss - best_known_loss > threshold.
# Equality is within tolerance. These are ABSOLUTE MSE gaps, not ratios.
ABSOLUTE_GAP_THRESHOLDS = [0.1]

# Relative gaps are descriptive CSV columns only. Leave them undefined when
# the reference is at or below this value; never inflate a near-zero denominator.
RELATIVE_REFERENCE_FLOOR = 1e-8


def validate():
    if not ABSOLUTE_GAP_THRESHOLDS:
        raise ValueError('At least one absolute threshold is required.')
    if any(isinstance(x,bool) or not isinstance(x,(float,int)) or
           not math.isfinite(x) or x < 0 for x in ABSOLUTE_GAP_THRESHOLDS):
        raise ValueError('Thresholds must be finite, nonnegative numbers.')
    if len(set(ABSOLUTE_GAP_THRESHOLDS)) != len(ABSOLUTE_GAP_THRESHOLDS):
        raise ValueError('Thresholds must be distinct.')
    if not math.isfinite(RELATIVE_REFERENCE_FLOOR) or RELATIVE_REFERENCE_FLOOR < 0:
        raise ValueError('Invalid relative-reference floor.')
