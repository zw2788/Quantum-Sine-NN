"""Generate threshold plots from existing seed-level results; never train."""
import sys
import subprocess
from pathlib import Path

def main():
    if len(sys.argv)>1:
        results=Path(sys.argv[1]).expanduser().resolve()
    else:
        import tkinter as tk
        from tkinter import filedialog
        root=tk.Tk();root.withdraw()
        selected=filedialog.askdirectory(title='Select merged/results folder containing config.json and w*/runs.csv')
        root.destroy()
        if not selected:return
        results=Path(selected)
    subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('plot_results.py')),
                    str(results),'--heatmap-only'],check=True)

if __name__=='__main__':main()
