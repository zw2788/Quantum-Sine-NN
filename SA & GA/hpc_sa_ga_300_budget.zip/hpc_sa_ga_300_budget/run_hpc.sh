#!/bin/bash
#SBATCH --partition=tiny
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:10:00
#SBATCH --output=submit_%j.out
# OPTIONAL sbatch-style controller, for users accustomed to the original .sh
# scripts. It only submits the array. Prefer bash submit.sh to avoid this extra
# queue wait. Nested submission must be allowed by your cluster.
set -eo pipefail
cd -- "${SLURM_SUBMIT_DIR:?Submit this script from the uploaded package directory}"
bash ./submit.sh
