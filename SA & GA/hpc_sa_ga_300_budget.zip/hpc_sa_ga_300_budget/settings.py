"""Edit this file, save it, then run run_experiment.py. No CLI options needed."""

# NETWORK GRID: WIDTHS specifies the FIRST hidden layer size.
# Decrease by one neuron per layer, stopping at 5, as in the original DSinNN.
# Example: width=10, depth=8 -> [10,9,8,7,6,5,5,5].
# Use mode='constant' only to reproduce the older constant-width experiments.
NETWORK_MODE = 'decreasing'
MIN_NEURONS_PER_LAYER = 5
WIDTHS = list(range(5, 31))
DEPTHS = list(range(1, 11))
# Run BOTH methods on the identical grid, data split and loss-evaluation budget.
METHODS = ['sa', 'ga']

# RANDOM SEEDS: each seed starts a new search from a new random initialization.
# It also controls subsequent random proposals, acceptance draws and GA operators.
# With START_SEED=0 and NUMBER_OF_SEEDS=3, the seeds are 0, 1 and 2.
# Set NUMBER_OF_SEEDS=200 for the planned larger experiment.
NUMBER_OF_SEEDS = 200
START_SEED = 0

# BUDGET PER SEED: total training-loss evaluations in ONE search run.
# SA: 1 initial evaluation + at most (budget - 1) candidate evaluations.
# GA: initial population evaluations + all evaluated offspring.
# This is NOT the number of complete searches and NOT the number of GA generations.
# Set MAX_EVALUATIONS_PER_SEED=300 for the planned larger experiment.
MAX_EVALUATIONS_PER_SEED = 300

# DATA: keep this fixed to use the same 160/40 split as the original experiment.
DATA_SPLIT_SEED = 42

# SIMULATED ANNEALING: positive start/end temperatures for geometric cooling.
# The evaluation budget determines how many steps connect these temperatures.
SA_START_TEMPERATURE = 4.0
SA_END_TEMPERATURE = 0.001

# GENETIC ALGORITHM: independent random initial population, one preserved elite.
# Retain the locally tested four-member population for this 300-evaluation run.
# These are baseline settings, not a population-size tuning study.
GA_POPULATION_SIZE = 4
GA_CROSSOVER_PROBABILITY = 0.9
# None means per-bit mutation probability 1/M, where M is the number of weights.
# Replace None with a probability, e.g. 0.1, to use the same rate for every model.
GA_MUTATION_PROBABILITY = None

# REPORTING: this tolerance is only for matching the retrospective best-known loss.
# It does not tell either optimizer a target loss or trigger early termination.
REFERENCE_LOSS_TOLERANCE = 1e-8

# PLOTS: export train/test absolute-gap miss-rate heatmaps for BOTH methods.
# One absolute tolerance (0.1) in plot_settings.py; four train/test heatmaps.
# Reference minima pool SA and GA for each architecture/split.
MAKE_PLOTS = True
# None selects the largest tested width/depth for the individual loss-curve figure.
CURVE_WIDTH = None
CURVE_DEPTH = None

# OUTPUT: None creates a fresh timestamped results subfolder on every launch.
# For resume, set a specific folder string, e.g. 'results/my_experiment', and
# set RESUME=True while keeping all search parameters identical to that run.
RESULTS_FOLDER = None
RESUME = False

# Disable this only if you also want the older diagnostic plots.
PLOT_ONLY_MISS = True
