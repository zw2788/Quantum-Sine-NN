"""Binary SA and GA sharing one objective-evaluation accounting interface."""
import numpy as np


def simulated_annealing(obj, rng, args):
    # Same seed starts both methods with the same first binary candidate.
    current = rng.choice([-1, 1], size=obj.model.n_weights).astype(np.int8)
    score = obj(current)
    while not obj.done:
        # Geometric cooling follows the planned budget, including rejected moves.
        progress = (len(obj.history)-1)/max(1, args.budget-2)
        temperature = args.t_start*(args.t_end/args.t_start)**progress
        proposal = current.copy()
        proposal[rng.integers(obj.model.n_weights)] *= -1
        new_score = obj(proposal)
        delta = new_score-score
        if delta <= 0 or rng.random() < np.exp(-delta/temperature):
            current, score = proposal, new_score


def genetic_algorithm(obj, rng, args):
    # Independent random chromosomes, with replacement; initialization is charged.
    population, scores = [], []
    for _ in range(args.population):
        if obj.done:
            return
        w = rng.choice([-1, 1], size=obj.model.n_weights).astype(np.int8)
        population.append(w)
        scores.append(obj(w))

    def parent():
        # Two-member tournament, with random ordering to resolve equal-loss ties.
        candidates = rng.choice(len(population), size=2, replace=False)
        return population[min(candidates, key=lambda i: scores[i])].copy()

    # The default 1/M mutation rate is configurable and recorded for each model.
    # At M=1 this flips every bit; at M=2 it randomizes every offspring bit.
    rate = 1/obj.model.n_weights if args.mutation is None else args.mutation
    while not obj.done:
        best = min(range(len(scores)), key=lambda i: scores[i])
        # Preserve one elite and reuse its fitness; this is not a new evaluation.
        children, fitness = [population[best].copy()], [scores[best]]
        while len(children) < args.population and not obj.done:
            first, second = parent(), parent()
            child = first.copy()
            if rng.random() < args.crossover:
                mask = rng.random(obj.model.n_weights) < 0.5
                child[mask] = second[mask]
            child[rng.random(obj.model.n_weights) < rate] *= -1
            fitness.append(obj(child))
            children.append(child)
        population, scores = children, fitness
