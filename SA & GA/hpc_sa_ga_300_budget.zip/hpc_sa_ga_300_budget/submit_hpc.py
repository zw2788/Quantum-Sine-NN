"""Submit a Slurm array, then merge and plot only after every task succeeds."""
import argparse
import csv
import contextlib
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parent
SOURCE_FILES = ['model.py', 'optimizers.py', 'run_grid.py', 'plot_results.py',
                'run_experiment.py', 'settings.py', 'hpc_settings.py', 'plot_settings.py',
                'submit_hpc.py', 'worker.sh', 'cluster_env.sh']


def load_module(path, name):
    # Read explicit files rather than relying on the terminal's working directory.
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def experiment_config(s):
    # Match run_grid.py's configuration schema exactly, including seed numbering.
    return dict(widths=list(s.WIDTHS), depths=list(s.DEPTHS), methods=list(s.METHODS),
        mode=s.NETWORK_MODE, min_width=s.MIN_NEURONS_PER_LAYER,
        seeds=s.NUMBER_OF_SEEDS, seed_start=s.START_SEED,
        budget=s.MAX_EVALUATIONS_PER_SEED, split_seed=s.DATA_SPLIT_SEED,
        t_start=s.SA_START_TEMPERATURE, t_end=s.SA_END_TEMPERATURE,
        population=s.GA_POPULATION_SIZE, crossover=s.GA_CROSSOVER_PROBABILITY,
        mutation=s.GA_MUTATION_PROBABILITY, reference_tol=s.REFERENCE_LOSS_TOLERANCE)


def validate(config):
    # Reject invalid or duplicate groups before spending scheduler resources.
    import math
    for key in ['widths', 'depths']:
        values = config[key]
        if not values or len(set(values)) != len(values) or any(type(v) is not int or v < 1 for v in values):
            raise ValueError(f'{key} must contain distinct positive integers.')
    if config['mode'] not in ['constant','decreasing'] or config['min_width'] < 1:
        raise ValueError('Invalid architecture mode/minimum width.')
    if config['mode'] == 'decreasing' and min(config['widths']) < config['min_width']:
        raise ValueError('First-layer widths must be >= minimum width.')
    if not config['methods'] or len(set(config['methods'])) != len(config['methods']) or any(m not in ['sa','ga'] for m in config['methods']):
        raise ValueError('METHODS must contain sa and/or ga, without duplicates.')
    for key in ['seeds', 'budget', 'population']:
        if type(config[key]) is not int or config[key] < (2 if key == 'population' else 1):
            raise ValueError(f'Invalid {key}.')
    for key in ['seed_start', 'split_seed']:
        if type(config[key]) is not int or config[key] < 0:
            raise ValueError(f'Invalid {key}.')
    if not all(math.isfinite(config[k]) for k in ['t_start','t_end','reference_tol','crossover']):
        raise ValueError('Temperatures, tolerance and crossover must be finite.')
    if not config['t_start'] >= config['t_end'] > 0 or config['reference_tol'] < 0:
        raise ValueError('Require t_start >= t_end > 0 and nonnegative tolerance.')
    if not 0 <= config['crossover'] <= 1 or (config['mutation'] is not None and not 0 <= config['mutation'] <= 1):
        raise ValueError('Invalid crossover/mutation probability.')


def estimated_work(task, config):
    # Weight count is only a scheduling heuristic, not a measured runtime claim.
    widths = [task['width'] if config['mode'] == 'constant' else
              max(config['min_width'], task['width']-i) for i in range(task['depth'])]
    weights = sum(a*b for a,b in zip([1]+widths[:-1], widths))
    return (weights + 100*task['depth']) * config['seeds'] * config['budget']


def make_bundles(tasks, config, count):
    # Greedy packing balances large/small networks while reducing submitted jobs.
    bundles = [[] for _ in range(min(count, len(tasks)))]
    loads = [0]*len(bundles)
    for index in sorted(range(len(tasks)), key=lambda i: estimated_work(tasks[i],config), reverse=True):
        slot = min(range(len(loads)), key=loads.__getitem__)
        bundles[slot].append(index)
        loads[slot] += estimated_work(tasks[index],config)
    return bundles


def prepare(destination=None):
    # Snapshot code and settings so later edits cannot silently change queued jobs.
    s = load_module(ROOT/'settings.py', 'experiment_settings')
    h = load_module(ROOT/'hpc_settings.py', 'cluster_settings')
    config = experiment_config(s)
    validate(config)
    load_module(ROOT/'plot_settings.py', 'plot_config').validate()
    for key in ['MAX_PARALLEL_TASKS','WORKERS_PER_TASK','SEEDS_PER_CHUNK','ARRAY_JOB_COUNT']:
        if type(getattr(h,key)) is not int or getattr(h,key) < 1:
            raise ValueError(key+' must be a positive integer.')
    for value, choices in [(s.CURVE_WIDTH,s.WIDTHS),(s.CURVE_DEPTH,s.DEPTHS)]:
        if value is not None and value not in choices:
            raise ValueError('Selected curve architecture must be in the grid.')
    run = (destination or ROOT/'hpc_runs'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')).resolve()
    run.mkdir(parents=True, exist_ok=False)
    code = run/'code'
    code.mkdir()
    for name in SOURCE_FILES:
        shutil.copy2(ROOT/name, code/name)
    (run/'logs').mkdir()
    tasks = [dict(width=w, depth=d, method=m) for w in config['widths']
             for d in config['depths'] for m in config['methods']]
    cluster = {k:getattr(h,k) for k in ['PARTITION','ACCOUNT','QOS','MAX_PARALLEL_TASKS',
               'MEMORY_PER_TASK','TIME_PER_TASK','MERGE_MEMORY','MERGE_TIME','PYTHON_EXECUTABLE',
               'WORKERS_PER_TASK','SEEDS_PER_CHUNK','ARRAY_JOB_COUNT']}
    bundles = make_bundles(tasks, config, h.ARRAY_JOB_COUNT)
    manifest = dict(format="bundled_seed_parallel_v2", settings=config, cluster=cluster, tasks=tasks, bundles=bundles,
        plots=dict(enabled=s.MAKE_PLOTS, width=s.CURVE_WIDTH, depth=s.CURVE_DEPTH,
                   heatmap_only=getattr(s,'PLOT_ONLY_MISS',True)),
        source_sha256={name:hashlib.sha256((code/name).read_bytes()).hexdigest() for name in SOURCE_FILES})
    (run/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(f'Prepared {len(tasks)} architecture/method groups in {len(bundles)} Slurm array jobs at {run}', flush=True)
    return run


def read_manifest(run):
    # Check frozen sources before either launching tasks or pooling their results.
    manifest = json.loads((run/'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('format') != 'bundled_seed_parallel_v2':
        raise ValueError('Old run layout: use that run/code/submit_hpc.py, or prepare a new run.')
    for name, digest in manifest['source_sha256'].items():
        if hashlib.sha256((run/'code'/name).read_bytes()).hexdigest() != digest:
            raise ValueError(f'Snapshot changed: {name}; create a fresh run instead.')
    return manifest


def task_config(manifest, task):
    config = dict(manifest['settings'])
    config.update(widths=[task['width']], depths=[task['depth']], methods=[task['method']])
    return config


def chunk_configs(manifest, task):
    # Seed numbering is identical to the serial version; partitioning changes
    # neither initialization nor subsequent proposal/acceptance random sequences.
    config = task_config(manifest, task)
    size = manifest['cluster']['SEEDS_PER_CHUNK']
    chunks = []
    for offset in range(0,config['seeds'],size):
        part = dict(config)
        part.update(seed_start=config['seed_start']+offset,
                    seeds=min(size,config['seeds']-offset))
        chunks.append(part)
    return chunks


def execute_chunk(run, dest, config):
    # Threads here supervise separate Python PROCESSES; CPU work is not executed
    # in Python threads. Every child has its own result directory and log.
    command = [sys.executable,'-B',str(run/'code'/'run_grid.py')]
    for key,value in config.items():
        if value is None:continue
        command += ['--'+key.replace('_','-')]
        command += [str(v) for v in value] if isinstance(value,list) else [str(value)]
    command += ['--output',str(dest)]
    if (dest/'config.json').exists():command += ['--resume']
    env = dict(os.environ)
    env.update(OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    with (dest.parent/(dest.name+'.log')).open('a',encoding='utf-8') as log:
        subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    print(f"Finished seeds {config['seed_start']}..{config['seed_start']+config['seeds']-1}",flush=True)


def assemble_task(run, index, manifest):
    # Validate every chunk before creating the complete group. The final report
    # pools ALL seeds, never averages chunk-level reference losses or miss rates.
    import numpy as np
    task = manifest['tasks'][index]
    config = task_config(manifest,task)
    dest = run/'tasks'/f'{index:05d}'
    name = f"w{task['width']}_d{task['depth']}_{task['method']}"
    rows, histories, raw_histories, all_weights, seed_arrays = [],[],[],[],[]
    versions = []
    reference_data = None
    for number,part in enumerate(chunk_configs(manifest,task)):
        base = dest/'chunks'/f'{number:05d}'
        group = base/name
        if not (group/'done.json').exists():
            raise RuntimeError(f'Incomplete seed chunk: {base}')
        meta = json.loads((base/'config.json').read_text(encoding='utf-8'))
        if meta['settings'] != part:raise ValueError('Chunk settings mismatch.')
        versions.append(meta['versions'])
        with (group/'runs.csv').open(encoding='utf-8-sig',newline='') as f:
            chunk_rows = list(csv.DictReader(f))
        expected = list(range(part['seed_start'],part['seed_start']+part['seeds']))
        if [int(r['seed']) for r in chunk_rows] != expected:
            raise ValueError('Missing, duplicate or misordered chunk seeds.')
        with np.load(group/'history.npz') as hist, np.load(group/'best_weights.npz') as weights:
            if hist['best_loss'].shape != (part['seeds'],config['budget']):
                raise ValueError('Chunk history shape mismatch.')
            if list(hist['seeds']) != expected or list(weights['seeds']) != expected:
                raise ValueError('History/weight seed mismatch.')
            if not np.allclose(hist['best_loss'][:,-1],[float(r['best_train_mse']) for r in chunk_rows],rtol=0,atol=1e-12):
                raise ValueError('Chunk loss/history mismatch.')
            histories.append(hist['best_loss'].copy())
            raw_histories.append(hist['evaluated_loss'].copy())
            all_weights.append(weights['weights'].copy())
            seed_arrays.append(hist['seeds'].copy())
            layer_widths=weights['layer_widths'].copy()
        with np.load(base/'dataset.npz') as data:
            if reference_data is None:reference_data={k:data[k].copy() for k in data.files}
            elif set(data.files)!=set(reference_data) or any(not np.array_equal(data[k],reference_data[k]) for k in reference_data):
                raise ValueError('Chunks have different training/test data.')
        rows.extend(chunk_rows)
    if any(v!=versions[0] for v in versions):raise ValueError('Chunk dependency versions differ.')
    seeds=np.concatenate(seed_arrays)
    expected=list(range(config['seed_start'],config['seed_start']+config['seeds']))
    if seeds.tolist()!=expected:raise ValueError('Combined seeds do not match requested seeds.')
    group=dest/name;group.mkdir(exist_ok=True)
    with (group/'runs.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    np.savez_compressed(group/'history.npz',width=task['width'],depth=task['depth'],method=task['method'],
        seeds=seeds,best_loss=np.concatenate(histories),evaluated_loss=np.concatenate(raw_histories))
    np.savez_compressed(group/'best_weights.npz',width=task['width'],depth=task['depth'],
        seeds=seeds,weights=np.concatenate(all_weights),layer_widths=layer_widths,network_mode=config['mode'])
    np.savez_compressed(dest/'dataset.npz',**reference_data)
    (dest/'config.json').write_text(json.dumps(dict(settings=config,versions=versions[0]),indent=2),encoding='utf-8')
    # done.json is written LAST, after all seed blocks have been verified.
    (group/'done.json').write_text(json.dumps(dict(completed_seeds=config['seeds'])),encoding='utf-8')


def run_task(run, index):
    manifest = read_manifest(run)
    if not 0 <= index < len(manifest['tasks']):raise ValueError('Invalid task index.')
    workers = manifest['cluster']['WORKERS_PER_TASK']
    allocated = int(os.environ.get('SLURM_CPUS_PER_TASK',workers))
    if workers>allocated:raise ValueError('Worker count exceeds allocated Slurm CPUs.')
    task=manifest['tasks'][index]
    dest=run/'tasks'/f'{index:05d}'
    chunks=chunk_configs(manifest,task)
    # Create the shared parent before starting worker threads (no mkdir race).
    (dest/'chunks').mkdir(parents=True,exist_ok=True)
    print(f"Task {index}: {len(chunks)} seed chunks, at most {workers} workers",flush=True)
    started=__import__('time').perf_counter()
    with ThreadPoolExecutor(max_workers=min(workers,len(chunks))) as executor:
        futures=[executor.submit(execute_chunk,run,dest/'chunks'/f'{number:05d}',part)
                 for number,part in enumerate(chunks)]
        for future in futures:future.result()
    assemble_task(run,index,manifest)
    (dest/'parallel_timing.json').write_text(json.dumps(dict(
        wall_seconds=__import__('time').perf_counter()-started,
        workers=workers,chunks=len(chunks)),indent=2),encoding='utf-8')


def bundle_lanes(manifest, index):
    # Each lane is one persistent Python process. It imports Torch once and then
    # evaluates several seed chunks, retaining exactly the original random seeds.
    if not 0 <= index < len(manifest['bundles']):
        raise ValueError('Invalid bundle index.')
    lanes = [[] for _ in range(manifest['cluster']['WORKERS_PER_TASK'])]
    loads = [0]*len(lanes)
    for task_index in manifest['bundles'][index]:
        task = manifest['tasks'][task_index]
        for number, part in enumerate(chunk_configs(manifest, task)):
            slot = min(range(len(loads)), key=loads.__getitem__)
            lanes[slot].append((task_index, number, part))
            loads[slot] += estimated_work(task, part)
    return lanes


def run_lane(run, index, lane):
    manifest = read_manifest(run)
    lanes = bundle_lanes(manifest,index)
    if not 0 <= lane < len(lanes):raise ValueError('Invalid worker lane.')
    # These imports stay within this child process; no cross-process RNG is shared.
    sys.path.insert(0,str(run/'code'))
    print(f'Bundle {index}, worker {lane}: loading numerical libraries...',flush=True)
    runner = load_module(run/'code'/'run_grid.py','persistent_grid')
    for task_index, number, config in lanes[lane]:
        dest = run/'tasks'/f'{task_index:05d}'/'chunks'/f'{number:05d}'
        argv = [str(run/'code'/'run_grid.py')]
        for key,value in config.items():
            if value is None:continue
            argv += ['--'+key.replace('_','-')]
            argv += [str(v) for v in value] if isinstance(value,list) else [str(value)]
        argv += ['--output',str(dest)]
        if (dest/'config.json').exists():argv += ['--resume']
        previous = sys.argv
        try:
            sys.argv = argv
            with (dest.parent/(dest.name+'.log')).open('a',encoding='utf-8') as log:
                with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
                    runner.main()
        finally:
            sys.argv = previous
        print(f'Bundle {index}, worker {lane}: group {task_index}, seeds '
              f"{config['seed_start']}..{config['seed_start']+config['seeds']-1} complete",flush=True)


def run_bundle(run, index):
    manifest = read_manifest(run)
    lanes = bundle_lanes(manifest,index)
    workers = len(lanes)
    if workers > int(os.environ.get('SLURM_CPUS_PER_TASK',workers)):
        raise ValueError('Worker count exceeds allocated Slurm CPUs.')
    # Shared directories are created before subprocesses start (no mkdir race).
    for task_index in manifest['bundles'][index]:
        (run/'tasks'/f'{task_index:05d}'/'chunks').mkdir(parents=True,exist_ok=True)
    env = dict(os.environ,OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
    commands = [[sys.executable,'-B',str(run/'code'/'submit_hpc.py'),'lane',str(run),
                 '--index',str(index),'--lane',str(lane)]
                for lane,items in enumerate(lanes) if items]
    print(f'Bundle {index}: {len(manifest["bundles"][index])} groups, {len(commands)} persistent workers',flush=True)
    with ThreadPoolExecutor(max_workers=len(commands)) as executor:
        futures = [executor.submit(subprocess.run,command,env=env,check=True) for command in commands]
        for future in futures:future.result()
    for task_index in manifest['bundles'][index]:
        assemble_task(run,task_index,manifest)
    print(f'Bundle {index} complete.',flush=True)


def merge(run):
    # Require every expected seed and group before calculating a pooled reference.
    # This prevents missing/failed jobs from becoming misleading zero-percent cells.
    import numpy as np
    manifest = read_manifest(run)
    config = manifest['settings']
    expected_seeds = list(range(config['seed_start'],config['seed_start']+config['seeds']))
    groups, dataset_paths, versions = [], [], []
    for index, task in enumerate(manifest['tasks']):
        base = run/'tasks'/f'{index:05d}'
        name = f"w{task['width']}_d{task['depth']}_{task['method']}"
        group = base/name
        if not (group/'done.json').exists():
            raise RuntimeError(f'Task {index} is incomplete. No pooled report generated.')
        task_manifest = json.loads((base/'config.json').read_text(encoding='utf-8'))
        if task_manifest['settings'] != task_config(manifest,task):
            raise ValueError(f'Task {index} settings mismatch.')
        versions.append(task_manifest['versions'])
        with (group/'runs.csv').open(encoding='utf-8-sig',newline='') as f:
            rows = list(csv.DictReader(f))
        if sorted(int(row['seed']) for row in rows) != expected_seeds:
            raise ValueError(f'Task {index} has missing or duplicate seeds.')
        for row in rows:
            if int(row['width']) != task['width'] or int(row['depth']) != task['depth'] or row['method'] != task['method']:
                raise ValueError(f'Task {index} contains a different architecture/method.')
            if not np.isfinite(float(row['best_train_mse'])):
                raise ValueError(f'Task {index} contains a nonfinite loss.')
        with np.load(group/'history.npz') as hist, np.load(group/'best_weights.npz') as weights:
            if hist['best_loss'].shape != (config['seeds'],config['budget']):
                raise ValueError(f'Task {index} history shape mismatch.')
            if list(hist['seeds']) != expected_seeds or list(weights['seeds']) != expected_seeds:
                raise ValueError(f'Task {index} history/weight seeds mismatch.')
            if not np.allclose(hist['best_loss'][:,-1], [float(r['best_train_mse']) for r in rows],rtol=0,atol=1e-12):
                raise ValueError(f'Task {index} history/loss mismatch.')
        groups.append((group,name))
        dataset_paths.append(base/'dataset.npz')
    if any(v != versions[0] for v in versions):
        raise ValueError('Dependency versions differ between tasks.')
    with np.load(dataset_paths[0]) as first:
        for path in dataset_paths[1:]:
            with np.load(path) as other:
                if set(first.files)!=set(other.files) or any(not np.array_equal(first[k],other[k]) for k in first.files):
                    raise ValueError('Dataset or train/test split differs between tasks.')
    dest = run/'merged'
    dest.mkdir(exist_ok=True)
    for group,name in groups:
        shutil.copytree(group,dest/name,dirs_exist_ok=True)
    shutil.copy2(dataset_paths[0],dest/'dataset.npz')
    (dest/'config.json').write_text(json.dumps(dict(settings=config,versions=versions[0]),indent=2),encoding='utf-8')
    sys.path.insert(0,str(run/'code'))
    runner = load_module(run/'code'/'run_grid.py','frozen_grid')
    runner.summarise(dest,SimpleNamespace(**config))
    if manifest['plots']['enabled']:
        command = [sys.executable,'-B',str(run/'code'/'plot_results.py'),str(dest)]
        if manifest['plots'].get('heatmap_only',True):command.append('--heatmap-only')
        for key in ['width','depth']:
            if manifest['plots'][key] is not None:
                command += ['--'+key,str(manifest['plots'][key])]
        subprocess.run(command,check=True)
    (dest/'MERGE_COMPLETE.txt').write_text('All expected tasks/seeds checked. References pooled across included methods.\n',encoding='utf-8')
    print(f'Complete results and figures: {dest}',flush=True)


def submit(run):
    # Submit only through Slurm. The exact selected Linux Python path is forwarded
    # to compute nodes; no Windows interpreter paths are used on the cluster.
    if os.name != 'posix' or shutil.which('sbatch') is None:
        raise RuntimeError('Submit on the HPC login node with Slurm available.')
    manifest = read_manifest(run)
    h = manifest['cluster']
    python = h['PYTHON_EXECUTABLE'] or sys.executable
    python = str(Path(python).expanduser().absolute())
    if (run/'submission.json').exists():
        raise RuntimeError('This run already has a submitted search job. Check submission.json and squeue before resubmitting.')
    # Import numerical and plotting dependencies separately, as in the jobs.
    print('Checking numerical libraries (Torch import can take time on shared storage)...',flush=True)
    subprocess.run([python,'-B','-c','import numpy, torch; print("Numerical dependencies OK")'],check=True)
    subprocess.run([python,'-B','-c','import matplotlib; print("Plotting dependency OK")'],check=True)
    base = ['sbatch','--parsable','--nodes=1','--ntasks=1',
            '--export=ALL','--chdir='+str(run)]
    for key, flag in [('PARTITION','partition'),('ACCOUNT','account'),('QOS','qos')]:
        if h[key]:
            base.append('--'+flag+'='+str(h[key]))
    worker = str(run/'code'/'worker.sh')
    driver = str(run/'code'/'submit_hpc.py')
    array_command = base+['--cpus-per-task='+str(h['WORKERS_PER_TASK']),'--job-name=dsinnn_search','--mem='+h['MEMORY_PER_TASK'],
        '--time='+h['TIME_PER_TASK'],f"--array=0-{len(manifest['bundles'])-1}%{min(h['MAX_PARALLEL_TASKS'],len(manifest['bundles']))}",
        '--output='+str(run/'logs'/'search_%A_%a.out'),worker,python,driver,'bundle',str(run)]
    print(f"Submitting {len(manifest['bundles'])} search jobs plus one dependent merge job.",flush=True)
    try:
        job = subprocess.check_output(array_command,text=True).strip().split(';')[0]
    except subprocess.CalledProcessError as exc:
        raise RuntimeError('Search array rejected; no search job was submitted by this attempt. If quota is still full, check squeue; reduce ARRAY_JOB_COUNT in hpc_settings.py and prepare a NEW run, or wait for existing jobs to finish.') from exc
    if not job.isdigit():
        raise RuntimeError('Unexpected sbatch output: '+job)
    record = dict(array_job=job,python=python)
    (run/'submission.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(f'Search array submitted: {job}',flush=True)
    # An afterok dependency waits for ALL array members to exit successfully.
    # If merge submission fails, search tasks remain valid and the saved ID is kept.
    merge_command = base+['--cpus-per-task=1','--job-name=dsinnn_merge','--mem='+h['MERGE_MEMORY'],
        '--time='+h['MERGE_TIME'],'--dependency=afterok:'+job,
        '--output='+str(run/'logs'/'merge_%j.out'),worker,python,driver,'merge',str(run)]
    try:
        merge_job = subprocess.check_output(merge_command,text=True).strip().split(';')[0]
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f'Search job {job} IS submitted, but merge submission failed. Do not resubmit the searches. Submit a separate merge job after a slot is available; submission.json records the search ID.') from exc
    record['merge_job'] = merge_job
    (run/'submission.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print(f'Merge job submitted: {merge_job}\nRun directory: {run}',flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',nargs='?',default='submit',choices=['submit','prepare','task','bundle','lane','merge'])
    p.add_argument('run',nargs='?',type=Path)
    p.add_argument('--index',type=int,default=None)
    p.add_argument('--lane',type=int,default=None)
    args = p.parse_args()
    if args.action == 'prepare':
        prepare(args.run)
    elif args.action == 'submit':
        if os.name != 'posix' or shutil.which('sbatch') is None:
            p.error('Upload to HPC, activate your Linux Python environment, then submit there.')
        run = args.run.resolve() if args.run else prepare()
        submit(run)
    else:
        if args.run is None:
            p.error('Specify the prepared run directory.')
        run = args.run.resolve()
        if args.action in ['task','bundle','lane']:
            index = args.index if args.index is not None else int(os.environ['SLURM_ARRAY_TASK_ID'])
            if args.action == 'lane':
                if args.lane is None:p.error('Specify --lane.')
                run_lane(run,index,args.lane)
            elif args.action == 'bundle':run_bundle(run,index)
            else:run_task(run,index)
        else:
            merge(run)


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, subprocess.CalledProcessError) as exc:
        print(f'ERROR: {exc}',file=sys.stderr,flush=True)
        sys.exit(1)
