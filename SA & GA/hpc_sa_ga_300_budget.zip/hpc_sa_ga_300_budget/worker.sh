#!/bin/bash
# Slurm resources are supplied by submit_hpc.py, using hpc_settings.py.
set -eo pipefail
source "$(dirname -- "$2")/cluster_env.sh"
set -u
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MPLBACKEND=Agg
export PYTHONDONTWRITEBYTECODE=1
# Python, frozen driver, action, frozen run directory.
exec "$1" -B "$2" "$3" "$4"
