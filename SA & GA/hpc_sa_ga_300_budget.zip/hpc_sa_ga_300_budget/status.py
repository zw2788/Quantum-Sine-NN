"""Show the selected run's recorded Slurm IDs and output status."""
import argparse
import json
from pathlib import Path
import subprocess

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run',nargs='?',type=Path)
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    if args.run is not None:
        run=args.run.resolve()
    else:
        candidates=sorted((root/'hpc_runs').glob('*/submission.json'))
        if not candidates:parser.error('No submitted run found. Run bash submit.sh first.')
        run=candidates[-1].parent
    record=json.loads((run/'submission.json').read_text(encoding='utf-8'))
    print('Run:',run,flush=True)
    ids=[record[k] for k in ['array_job','merge_job'] if k in record]
    subprocess.run(['squeue','-j',','.join(ids)],check=False)
    if (run/'merged'/'MERGE_COMPLETE.txt').exists():
        print('COMPLETE: all expected results checked and figures generated.')
        print('Download:',run/'merged')
    else:
        print('No completed merge yet. An empty queue alone does not prove success.')
        print('Inspect accounting below and logs in:',run/'logs')
        subprocess.run(['sacct','-j',','.join(ids),'--format=JobID,JobName,State,ExitCode,Elapsed'],check=False)

if __name__=='__main__':
    main()
