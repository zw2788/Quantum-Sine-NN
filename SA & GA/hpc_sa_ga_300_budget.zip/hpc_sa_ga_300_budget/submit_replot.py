"""Submit a frozen plotting-only job; read existing results without modifying them."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime
import hpc_settings
import plot_settings

ROOT=Path(__file__).resolve().parent
FILES=['plot_results.py','plot_settings.py','replot_task.py','worker.sh','cluster_env.sh']

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results',nargs='?',type=Path,help='Existing merged/results folder, not its figures subfolder.')
    parser.add_argument('--latest-from',type=Path,help='Find the latest completed merged run under this HPC package directory.')
    args=parser.parse_args()
    if os.name!='posix' or shutil.which('sbatch') is None:
        parser.error('Run on the HPC login node. Locally use replot_only.bat instead.')
    plot_settings.validate()
    if (args.results is None)==(args.latest_from is None):
        parser.error('Specify either a results directory OR --latest-from PACKAGE_DIRECTORY.')
    if args.latest_from is not None:
        candidates=sorted(args.latest_from.expanduser().resolve().glob('hpc_runs/*/merged/MERGE_COMPLETE.txt'))
        if not candidates:parser.error('No completed merged run found there; check the previous merge job.')
        results=candidates[-1].parent.resolve()
    else:
        results=args.results.expanduser().resolve(strict=True)
    print('Reading existing results:',results,flush=True)
    settings=json.loads((results/'config.json').read_text(encoding='utf-8'))['settings']
    for width in settings['widths']:
        for depth in settings['depths']:
            for method in settings['methods']:
                path=results/f'w{width}_d{depth}_{method}'/'runs.csv'
                if not path.is_file():parser.error(f'Missing {path}; supply the complete merged folder.')
    job=ROOT/'replot_jobs'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    code=job/'code';code.mkdir(parents=True,exist_ok=False)
    for name in FILES:shutil.copy2(ROOT/name,code/name)
    output=job/'threshold_figures'
    (job/'manifest.json').write_text(json.dumps(dict(source_results=str(results),
        experiment_settings=settings,thresholds=plot_settings.ABSOLUTE_GAP_THRESHOLDS,
        threshold_mode='absolute',source_sha256={n:hashlib.sha256((code/n).read_bytes()).hexdigest() for n in FILES}),indent=2),encoding='utf-8')
    python=str(Path(hpc_settings.PYTHON_EXECUTABLE or sys.executable).expanduser().absolute())
    command=['sbatch','--parsable','--nodes=1','--ntasks=1','--cpus-per-task=1',
             '--export=ALL','--job-name=dsinnn_replot','--mem='+hpc_settings.MERGE_MEMORY,
             '--time='+hpc_settings.MERGE_TIME,'--chdir='+str(job),'--output='+str(job/'plot_%j.out')]
    for key,flag in [('PARTITION','partition'),('ACCOUNT','account'),('QOS','qos')]:
        value=getattr(hpc_settings,key)
        if value:command.append('--'+flag+'='+str(value))
    command += [str(code/'worker.sh'),python,str(code/'replot_task.py'),str(results),str(output)]
    completed=subprocess.run(command,text=True,capture_output=True)
    if completed.returncode:
        raise SystemExit('Plot job rejected; no searches were submitted.\n'+completed.stderr)
    jobid=completed.stdout.strip().split(';')[0]
    if not jobid.isdigit():raise SystemExit('Unexpected sbatch output: '+completed.stdout)
    (job/'submission.json').write_text(json.dumps(dict(job_id=jobid,command=command),indent=2),encoding='utf-8')
    print('Plot-only job submitted:',jobid)
    print('Check: squeue -j '+jobid)
    print('New figures:',output)
    print('Success marker:',output/'PLOTS_COMPLETE.txt')

if __name__=='__main__':main()
