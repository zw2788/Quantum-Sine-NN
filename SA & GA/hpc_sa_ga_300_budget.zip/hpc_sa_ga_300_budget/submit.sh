#!/bin/bash
# Run on the login node: bash submit.sh
# This only prepares/submits jobs; the searches run on allocated compute nodes.
set -eo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./cluster_env.sh
set -u
exec python -B submit_hpc.py "$@"
