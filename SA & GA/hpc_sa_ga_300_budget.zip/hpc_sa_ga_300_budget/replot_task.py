"""Compute-node entry point for a plotting-only Slurm job."""
import subprocess
import sys
from pathlib import Path

if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Expected input results directory and new output directory.')
    subprocess.run([sys.executable,'-B',str(Path(__file__).with_name('plot_results.py')),
                    sys.argv[1],'--heatmap-only','--output-directory',sys.argv[2]],check=True)
