"""Slurm resources. Defaults follow the user's existing Burgundy submit scripts."""

# Existing Discrete/*.sh scripts use this partition. Its present availability and
# per-user limits still need confirmation on the cluster; no account is invented.
PARTITION = 'tiny'
ACCOUNT = None
QOS = None

# Pack all architectures into a few Slurm jobs to respect submission quotas.
# Four search jobs + one merge job require FIVE available submission slots.
ARRAY_JOB_COUNT = 4
# Each job uses two persistent Python workers; Torch loads once per worker.
WORKERS_PER_TASK = 2
SEEDS_PER_CHUNK = 100
# With 200 seeds: chunks 0..99 and 100..199 run concurrently. Never use one thread
# per seed; every child gets one CPU thread to avoid BLAS/OpenMP oversubscription.
MAX_PARALLEL_TASKS = 4
MEMORY_PER_TASK = '8G'
TIME_PER_TASK = '04:00:00'
MERGE_MEMORY = '4G'
MERGE_TIME = '01:00:00'

# The selected environment interpreter is used on all compute nodes. Normally
# leave None and let cluster_env.sh activate your existing sinenv environment.
PYTHON_EXECUTABLE = None
