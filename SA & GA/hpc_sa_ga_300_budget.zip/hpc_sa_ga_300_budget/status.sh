#!/bin/bash
# Inspect a run; this helper does not create, cancel or resubmit jobs.
set -eo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./cluster_env.sh
set -u
python -B status.py "$@"
