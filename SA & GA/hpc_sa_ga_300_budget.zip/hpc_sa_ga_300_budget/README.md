# SA + GA: 300 evaluations per seed, absolute MSE tolerance 0.1

Upload hpc_sa_ga_300_budget.zip into /gpfs1/home/zujinwen2/QSINNN2ndSub/SAGA.
Run on the login node:

```bash
cd /gpfs1/home/zujinwen2/QSINNN2ndSub/SAGA
unzip hpc_sa_ga_300_budget.zip
cd hpc_sa_ga_300_budget
bash submit.sh
squeue -u "$USER"
```

This starts a NEW experiment. Old 50-evaluation results are not overwritten.
260 decreasing-width architectures per method: first-layer width 5..30,
hidden layers 1..10, layer widths max(5, W-l+1). Both SA and GA run
200 seeds (0..199), up to 300 full training-MSE evaluations per seed.
Same 160/40 train/test split (seed 42), network, data and loss as before.
SA: one-bit proposals, geometric cooling from 4 to 0.001, including rejected proposals.
Changing the budget stretches cooling over 299 proposals; the first 50 evaluations
are NOT the same schedule as a separate 50-budget run.
GA: population 4, tournament size 2, crossover 0.9, mutation 1/M, one elite.
Zero training loss permits early stopping. Test data never guide optimization.
Maximum training evaluations: 260 * 2 * 200 * 300 = 31,200,000.

Four bundled Slurm search jobs, two persistent workers each, plus one dependent
merge/plot job. Resources remain tiny, 8G, 4 hours per search job. No new queue
limits are assumed. Check status if the longer budget approaches the time limit;
a missing group is an error, not a zero-valued heatmap cell.

```bash
bash status.sh
```

The dependent merge job automatically generates four heatmaps, each as PNG and SVG:
SA train, SA test, GA train, GA test. No cell numbers; original DSinNN plot style.
Output: hpc_runs/<timestamp>/merged/threshold_figures/<timestamp>/absolute_gap_0p1/.
A miss means loss - best-known loss > 0.1; equality is within tolerance.
References pool BOTH methods in this NEW run, separately for each architecture
and train/test split. These are observed minima, not certified global minima.
Old 50-budget plots use their own references: do not directly compare percentages
across those plots without recomputing both against a shared reference.

Edit settings.py for future run parameters; plot_settings.py controls [0.1].
Changing root settings does not change an already prepared run's frozen code.

The manuscript currently says B=50; update it to B=300 after adopting these results.
