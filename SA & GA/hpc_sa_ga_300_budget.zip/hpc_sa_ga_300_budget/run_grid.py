"""Run a configurable DSinNN architecture grid (decreasing or constant width) with SA and GA."""
import argparse
import csv
import json
import math
import platform
import time
from datetime import datetime
from pathlib import Path
import numpy as np
import torch
from model import DSinNN, Objective, make_data
from optimizers import simulated_annealing, genetic_algorithm


def write_csv(path, rows):
    # UTF-8 BOM makes column labels straightforward to open in Windows Excel.
    if not rows:
        return
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarise(folder, args):
    # Pool final best training losses across BOTH methods for each architecture.
    # References are retrospective best-known values, not certified global minima.
    all_rows = []
    for path in sorted(folder.glob('*/runs.csv')):
        with path.open(encoding='utf-8-sig', newline='') as f:
            all_rows.extend(csv.DictReader(f))
    references = {}
    for row in all_rows:
        key = (int(row['width']), int(row['depth']))
        references[key] = min(references.get(key, math.inf), float(row['best_train_mse']))
    for row in all_rows:
        ref = references[int(row['width']), int(row['depth'])]
        loss = float(row['best_train_mse'])
        row.update(reference_best_known_mse=ref, gap_to_reference=loss-ref,
                   reaches_best_known=int(loss <= ref+args.reference_tol),
                   bad_vs_reference=int((loss-ref)/(ref+1e-8)>1 and loss-ref>0.0001))
    write_csv(folder/'all_runs.csv', all_rows)
    summaries = []
    for width, depth in sorted(references):
        for method in args.methods:
            rows = [r for r in all_rows if int(r['width'])==width and int(r['depth'])==depth and r['method']==method]
            if not rows:
                continue
            # Test MSE belongs to each run's training-selected best weights. The
            # test set never selects candidates, temperatures, or reference loss.
            summaries.append(dict(width=width, depth=depth, n_weights=int(rows[0]['n_weights']),
                method=method, completed_seeds=len(rows), reference_best_known_mse=references[width, depth],
                hit_best_known_rate=np.mean([r['reaches_best_known'] for r in rows]),
                bad_vs_reference_rate=np.mean([r['bad_vs_reference'] for r in rows]),
                mean_train_mse=np.mean([float(r['best_train_mse']) for r in rows]),
                mean_test_mse=np.mean([float(r['test_mse']) for r in rows]),
                mean_evaluations=np.mean([int(r['evaluations']) for r in rows]),
                mean_search_seconds=np.mean([float(r['search_seconds']) for r in rows])))
    write_csv(folder/'summary.csv', summaries)
    # Recompute budget-success curves against the CURRENT pooled reference.
    # When a new method finds a lower loss, all curves use that same updated value.
    curves = []
    for path in sorted(folder.glob('*/history.npz')):
        with np.load(path) as data:
            width, depth = int(data['width']), int(data['depth'])
            method = str(data['method'].item())
            history = data['best_loss']
            ref = references[width, depth]
            for j in range(history.shape[1]):
                curves.append(dict(width=width, depth=depth, method=method, budget=j+1,
                    reference_best_known_mse=ref,
                    hit_best_known_rate=float(np.mean(history[:, j] <= ref+args.reference_tol)),
                    mean_best_train_mse=float(np.mean(history[:, j]))))
    write_csv(folder/'curves.csv', curves)


def main():
    # Width denotes the first layer. Default: decreasing to a floor of 5.
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode', choices=['constant','decreasing'], default='decreasing')
    p.add_argument('--min-width', type=int, default=5)
    p.add_argument('--widths', nargs='+', type=int, default=list(range(5,11)))
    p.add_argument('--depths', nargs='+', type=int, default=list(range(1,4)))
    p.add_argument('--methods', nargs='+', choices=['sa','ga'], default=['sa','ga'])
    p.add_argument('--seeds', type=int, default=200)
    p.add_argument('--seed-start', type=int, default=0)
    p.add_argument('--budget', type=int, default=300)
    p.add_argument('--split-seed', type=int, default=42)
    p.add_argument('--t-start', type=float, default=4)
    p.add_argument('--t-end', type=float, default=0.001)
    p.add_argument('--population', type=int, default=20)
    p.add_argument('--crossover', type=float, default=0.9)
    p.add_argument('--mutation', type=float, default=None, help='Default: 1/number_of_weights.')
    p.add_argument('--reference-tol', type=float, default=1e-8)
    p.add_argument('--output', type=Path, default=None)
    p.add_argument('--resume', action='store_true')
    args = p.parse_args()
    if any(v<1 for v in args.widths+args.depths) or args.seeds<1 or args.budget<1 or args.seed_start<0 or args.split_seed<0:
        p.error('Widths/depths/seeds/budget must be positive; seeds nonnegative.')
    if args.min_width < 1 or (args.mode == 'decreasing' and min(args.widths) < args.min_width):
        p.error('Decreasing mode requires first-layer widths >= min-width >= 1.')
    if not math.isfinite(args.t_start) or not math.isfinite(args.t_end) or not args.t_start>=args.t_end>0:
        p.error('Require finite t-start >= t-end > 0.')
    if args.population<2 or not 0<=args.crossover<=1 or (args.mutation is not None and not 0<=args.mutation<=1):
        p.error('Population >=2; crossover and mutation in [0,1].')
    if not math.isfinite(args.reference_tol) or args.reference_tol<0:
        p.error('Reference tolerance must be finite and nonnegative.')
    args.widths, args.depths, args.methods = list(dict.fromkeys(args.widths)), list(dict.fromkeys(args.depths)), list(dict.fromkeys(args.methods))
    # One Torch thread avoids excessive small-matrix thread overhead. No training
    # gradients are retained; the model uses inference-mode tensor operations.
    torch.set_num_threads(1)
    folder = args.output or Path(__file__).resolve().parent/'results'/datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    config = {k:v for k,v in vars(args).items() if k not in ['output','resume']}
    manifest = folder/'config.json'
    if args.resume:
        if not manifest.exists() or json.loads(manifest.read_text(encoding='utf-8'))['settings'] != config:
            p.error('Resume requires an existing --output with identical experiment settings.')
    elif folder.exists() and any(folder.iterdir()):
        p.error('Output directory is not empty; choose a new directory or use --resume.')
    folder.mkdir(parents=True, exist_ok=True)
    manifest.write_text(json.dumps(dict(settings=config, versions=dict(python=platform.python_version(),
        numpy=np.__version__, torch=torch.__version__)), indent=2), encoding='utf-8')
    data = make_data(args.split_seed)
    # Save exact data and indices so the experimental split is independently auditable.
    np.savez_compressed(folder/'dataset.npz', **{k:v.numpy() for k,v in data.items()})
    total = len(args.widths)*len(args.depths)*len(args.methods)
    group = 0
    for width in args.widths:
        for depth in args.depths:
            model = DSinNN(width, depth, args.mode, args.min_width)
            for method in args.methods:
                group += 1
                dest = folder/f'w{width}_d{depth}_{method}'
                # Resume granularity is one completed architecture/method group.
                # Interrupted groups are recomputed; only done.json marks completion.
                if (dest/'done.json').exists():
                    print(f'[{group}/{total}] skipping completed {dest.name}', flush=True)
                    continue
                dest.mkdir(exist_ok=True)
                runs, histories, raw_histories, weights = [], [], [], []
                algorithm = simulated_annealing if method=='sa' else genetic_algorithm
                for seed in range(args.seed_start, args.seed_start+args.seeds):
                    obj = Objective(model, data, args.budget)
                    start = time.perf_counter()
                    algorithm(obj, np.random.default_rng(seed), args)
                    elapsed = time.perf_counter()-start
                    n = len(obj.history)
                    # Evaluate held-out data ONLY for the best training candidate.
                    test_mse = model.loss(obj.best_weights, data['test_x'], data['test_y'])
                    # Output magnitude cannot exceed the FINAL hidden layer width. This is a lower bound
                    # from limited output range, not generally an attainable optimum.
                    lower_bound = float(torch.mean(torch.clamp(data['train_y'].abs()-model.output_width,min=0)**2).item())
                    runs.append(dict(width=width, depth=depth, n_weights=model.n_weights, method=method,
                        network_mode=args.mode, layer_widths='-'.join(map(str,model.layer_widths)),
                        seed=seed, evaluations=n, unique_evaluations=len(obj.unique), best_train_mse=obj.best_loss,
                        test_mse=test_mse, output_range_lower_bound=lower_bound, search_seconds=elapsed,
                        mutation_rate=(1/model.n_weights if args.mutation is None else args.mutation) if method=='ga' else '',
                        reached_zero=int(obj.best_loss==0)))
                    # Best-history tails are carried forward after early success.
                    # Raw-history tails are NaN, indicating no actual evaluations.
                    histories.append(obj.best_history+[obj.best_loss]*(args.budget-n))
                    raw_histories.append(obj.history+[float('nan')]*(args.budget-n))
                    weights.append(obj.best_weights)
                    if (seed-args.seed_start+1)%10==0 or seed==args.seed_start+args.seeds-1:
                        print(f'[{group}/{total}] {dest.name}: {seed-args.seed_start+1}/{args.seeds} seeds', flush=True)
                write_csv(dest/'runs.csv', runs)
                np.savez_compressed(dest/'history.npz', width=width, depth=depth, method=method,
                    best_loss=np.asarray(histories), evaluated_loss=np.asarray(raw_histories),
                    seeds=np.arange(args.seed_start,args.seed_start+args.seeds))
                np.savez_compressed(dest/'best_weights.npz', weights=np.asarray(weights),
                    seeds=np.arange(args.seed_start,args.seed_start+args.seeds), width=width, depth=depth,
                    network_mode=args.mode, layer_widths=np.asarray(model.layer_widths))
                (dest/'done.json').write_text(json.dumps(dict(completed_seeds=args.seeds)), encoding='utf-8')
    # Summaries are created after the grid is complete. Group files remain usable
    # if execution is interrupted; --resume finishes remaining groups.
    summarise(folder, args)
    print(f'Completed. Results: {folder}', flush=True)


if __name__ == '__main__':
    main()
