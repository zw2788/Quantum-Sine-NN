@echo off
setlocal
cd /d "%~dp0"
set "MPLBACKEND=Agg"
"%USERPROFILE%\Anaconda3\python.exe" -B run_experiment.py
pause
